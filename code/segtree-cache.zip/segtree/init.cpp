#include "segtree.h"
#include <vector>
#include <algorithm>
#include <cassert>

extern int* pos;
extern int* lev;
extern bool* mark;

node* build_tree(int L, int R, int &id)
{
	node *nd = pool + (id++);
	nd->tg = tag();
	nd->dat = data();
	if (L == R) {
		nd->lc = nd->rc = nullptr;
		return nd;
	} else {
		int mid = (L + R) >> 1;
		nd->lc = build_tree(L, mid, id);
		nd->rc = build_tree(mid+1, R, id);
		return nd;
	}
}

void init_normal(int n)
{
	N = n, root = nullptr;
	int top = 1;
	root = build_tree(1, N, top);
}

int dfs_height(node *nd)
{
	if (nd == nullptr)
		return 0;
	return std::max(dfs_height(nd->lc), dfs_height(nd->rc)) + 1;
}

void dfs_relabel(node *nd, int h, int &id, std::vector<node*> &que)
{
	if (nd == nullptr)
		return;
	if (h == 1) {
		pos[nd - pool] = id++;
		if (nd->lc != nullptr) {
			que.push_back(nd->lc);
		}
		if (nd->rc != nullptr) {
			que.push_back(nd->rc);
		}
	} else {
		std::vector<node*> q;
		int up = h / 2, down = h - up;
		dfs_relabel(nd, up, id, q);
		for (auto nxt : q) {
			dfs_relabel(nxt, down, id, que);
		}
	}
}

void relabel_node()
{
	int top = 1, h = dfs_height(root);
	std::vector<node*> v;
	dfs_relabel(root, h, top, v);
	assert(v.empty());
}

extern node *pool_2;

void init_cache_oblivious(int n)
{
	N = n, root = nullptr;
	int top = 1;
	root = build_tree(1, N, top);
	relabel_node();
	for (int i = 1; i < top; i++) {
		node *nd = pool + i;
		if (nd->lc != nullptr) {
			nd->lc = pool_2 + pos[nd->lc - pool];
			nd->rc = pool_2 + pos[nd->rc - pool];
		} 
	}
	for (int i = 1; i < top; i++) {
		pool_2[pos[i]] = pool[i];
	}
	root = pool_2 + pos[root - pool];
	pool = pool_2;
}

