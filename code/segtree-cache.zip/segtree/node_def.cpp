#include "segtree.h"
#include <algorithm>

using std::max;

const int MAXN = 1 << 22;

node __pool[MAXN << 1 | 1];
node __pool_2[MAXN << 1 | 1];
node *pool = __pool;
node *pool_2 = __pool_2;

int __renumber[MAXN << 1 | 1];
int* pos = __renumber;

int __lev[MAXN << 1 | 1];
bool __mark[MAXN << 1 | 1];
int* lev = __lev;
bool* mark = __mark;

data::data()
{ max_value = 0; }

data::data(int max_value)
{ this->max_value = max_value; } 

data operator + (const data &a, const data &b)
{
	return data(max(a.max_value, b.max_value));
}

tag::tag()
{ addition = 0; }

tag::tag(int addition)
{ this->addition = addition; }

tag operator * (const tag &a, const tag &b)
{
	return tag(a.addition + b.addition);
}

data operator * (const tag &a, const data &dat)
{
	return dat.max_value + a.addition;
}

