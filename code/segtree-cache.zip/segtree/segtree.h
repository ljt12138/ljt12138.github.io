#pragma once

/**
 * segment tree interface
 */

void segment_add(int L, int R, int add);
int query_max(int L, int R);

void init_normal(int N);
void init_cache_oblivious(int N);

extern const int MAXN;
extern int N;

struct data {
	int max_value;
	data();
	data(int);
};

struct tag {
	int addition;
	tag();
	tag(int);
};

struct node {
	data dat;
	tag tg;
	node *lc, *rc;
};

extern node *pool;
extern node *root;

data operator + (const data &a, const data &b);
tag operator * (const tag &a, const tag &b);
data operator * (const tag &a, const data &dat);

