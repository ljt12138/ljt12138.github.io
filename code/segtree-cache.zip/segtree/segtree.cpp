#include <algorithm>
#include <cassert>
#include <cstdio>
#include "segtree.h"
using std::max;

node *root;

int N;

void put_tag(node *nd, const tag &tg)
{
	nd->dat = tg * nd->dat;
	nd->tg = tg * nd->tg;
}

void pdw(node *nd)
{
	put_tag(nd->lc, nd->tg);
	put_tag(nd->rc, nd->tg);
	nd->tg = tag();
}

void modify(node *nd, int L, int R, int opl, int opr, const tag &add)
{
	if (L == opl && R == opr) put_tag(nd, add);
	else {
		pdw(nd);
		int mid = (L + R) >> 1;
		if (opr <= mid) modify(nd->lc, L, mid, opl, opr, add);
		else if (opl > mid) modify(nd->rc, mid+1, R, opl, opr, add);
		else {
			modify(nd->lc, L, mid, opl, mid, add);
			modify(nd->rc, mid+1, R, mid+1, opr, add);
		}
		nd->dat = nd->lc->dat + nd->rc->dat;
	}
}

data query(node *nd, int L, int R, int opl, int opr)
{
	if (L == opl && R == opr) return nd->dat;
	else {
		pdw(nd);
		int mid = (L + R) >> 1;
		if (opr <= mid) return query(nd->lc, L, mid, opl, opr);
		else if (opl > mid) return query(nd->rc, mid+1, R, opl, opr);
		else {
			return query(nd->lc, L, mid, opl, mid)
				+  query(nd->rc, mid+1, R, mid+1, opr);
		}
	}
}

void segment_add(int L, int R, int add)
{
	assert(1 <= L && L <= R && R <= N);
	modify(root, 1, N, L, R, add);
}

int query_max(int L, int R)
{
	assert(1 <= L && L <= R && R <= N);
	return query(root, 1, N, L, R).max_value;
}
