#include "segtree/segtree.h"
#include <cstdlib>
#include <cassert>
#include <ctime>
#include <cstdio>
#include <algorithm>

void test_init()
{
	srand(19260817);
}

void test(int N)
{
	test_init();
	int ans = 0;
	for (int i = 1; i <= N; i++) {
		int r = rand() % 2;
		if (r == 0) {
			int L = rand()%N+1, R = rand()%N+1, add = rand() % 1000 + 1;
			if (L > R) std::swap(L, R);
			segment_add(L, R, add);
		    // printf("%d %d -> %d\n", L, R, add);
		} else {
			int L = rand()%N+1, R = rand()%N+1;
			if (L > R) std::swap(L, R);
		    // printf("%d %d <- %d\n", L, R, query_max(L, R));
			ans ^= query_max(L, R);
		}
	}
	printf("check value %d\n", ans);
}

void test_normal(int N)
{
	printf("-- start testing normal segtree --\n");
	clock_t s = clock();
	init_normal(N);
	test(N);
	clock_t e = clock();
	printf("-- total time : %.3f sec --\n", (double)(e-s)/CLOCKS_PER_SEC);
}

void test_cache_oblivious(int N)
{	
	printf("-- start testing cache oblivious segtree --\n");
	clock_t s = clock();	
	init_cache_oblivious(N);
	test(N);
	clock_t e = clock();
	printf("-- total time : %.3f sec --\n", (double)(e-s)/CLOCKS_PER_SEC);
}

int main(int argc, char **argv)
{
	assert(argc == 2);
	int number = atoi(argv[1]);
	assert(0 <= number && number <= MAXN);
	test_normal(number);
	test_cache_oblivious(number);
	return 0;
}

