#pragma once

void brute_preprocess();
int brute_query(int u, int k);
