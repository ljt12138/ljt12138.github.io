#include "brute_jump.h"
#include "../tree/tree.h"
#include <vector>
#include <cassert>
#include <cstdio>

using std::vector;

static vector< vector<int> > parent; 
static int lgn, n;

static void dfs_init(int nd, int fa)
{
	parent[0][nd] = fa;
	for (int to : tree[nd]) {
		if (to == fa) continue;
		dfs_init(to, nd);
	}
}

void brute_preprocess()
{
	lgn = 0, n = 1;
	while (n < N) {
		n <<= 1;
		lgn++;
	}
	parent.resize(lgn+1);
	for (int i = 0; i <= lgn; i++)
		parent[i].resize(N+1);
	dfs_init(root, 0);
	for (int i = 1; i <= lgn; i++) {
		for (int j = 1; j <= N; j++)
			parent[i][j] = parent[i-1][parent[i-1][j]];
	}
}

int brute_query(int u, int k)
{
	for (int d = 0; d <= lgn; d++) {
		if (k >> d & 1)
			u = parent[d][u];
	}
	assert(u != 0);
	return u;
}
