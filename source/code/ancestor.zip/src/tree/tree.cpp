#include "tree.h"
#include <cassert>
#include <algorithm>

using std::max;
using std::vector;

int N;
vector< std::vector<int> > tree;
vector< int > depth;
vector< int > siz;
vector< int > height;
vector< int > father;

// nodes are 1-indexed
int root;

void init_tree(int n, int rt)
{
	N = n;
	root = rt;
	tree.resize(N + 1);
	depth.resize(N + 1);
	siz.resize(N + 1);
	height.resize(N + 1);
	father.resize(N + 1);
}

void push_tree(int u, int v)
{
	assert(1 <= u && u <= N);
	assert(1 <= v && v <= N);
	tree[u].push_back(v);
	tree[v].push_back(u);
}

static void dfs(int nd, int fa)
{
	depth[nd] = depth[fa] + 1;
	father[nd] = fa;
	siz[nd] = 1;
	height[nd] = 1;
	for (int to : tree[nd]) {
		if (to == fa) continue;
		dfs(to, nd);
	    siz[nd] += siz[to];
		height[nd] = max(height[nd], height[to] + 1);
	}
}

void preprocess_tree()
{
	depth[0] = father[0] = 0;
	dfs(root, 0);
}

