#pragma once
#include <vector>

extern std::vector< std::vector<int> > tree;
extern std::vector< int > depth, siz, height, father;
extern int root;
extern int N;

void init_tree(int n, int rt);
void push_tree(int u, int v);
void preprocess_tree();
