#pragma once

void std_preprocess();
int std_query(int n, int k);
