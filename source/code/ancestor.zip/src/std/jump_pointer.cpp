#include "../tree/tree.h"
#include "jump_pointer.h"
#include <vector>
#include <cassert>
#include <cstdio>
#include <cstdlib>

using std::vector;
using std::max;

static int lgn, n;
static vector< int > hash_value;
static vector< int > vis;
static vector< int > id, block_top, block_id;
static vector< int > block_ptr, block_array;
static vector< vector<int> > parent;
static vector< vector< vector<int> > > table;
static vector< int > lg;
static int id_keypt;

static void dfs_fix(int nd, int fa, int &id_cnt, int rt)
{
	// get info of block
	id[nd] = ++id_cnt;
	block_ptr[nd] = block_array.size() - id[nd];
	block_array.push_back(nd);
	block_top[nd] = father[rt];
	block_id[nd] = hash_value[rt];
	for (int to : tree[nd]) {
		if (to == fa || vis[to] != 1) continue;
		dfs_fix(to, nd, id_cnt, rt);
	}
}

static void dfs_calc(int nd, int fa, vector< vector<int> > &dp)
{
	int cur_id = id[nd];
	for (int cur = nd; vis[cur] != -1; cur = father[cur]) {
		dp[cur_id].push_back(id[cur]);
	}
	for (int to : tree[nd]) {
		if (to == fa || vis[to] == -1) continue;
		dfs_calc(to, nd, dp);
	}
}

static vector<int> stk;

static int dfs_cut(int nd, int fa, int bound)
{
	stk.push_back(nd);
	vis[nd] = 0;
	int siz = 1, hv = 1;
	for (int to : tree[nd]) {
		if (to == fa) continue;
	    int cur_size = dfs_cut(to, nd, bound);
		siz += cur_size;
		if (vis[to] != -1) {
			assert(cur_size != 0);
			hv = (hv << (cur_size * 2)) | hash_value[to];
		}
	}
	hash_value[nd] = hv << 1;
	if (siz < bound && fa != 0) {
		vis[nd] = 1;
		stk.pop_back();
		return siz;
	} else {
		vis[nd] = -1;
		// set as key point
		for (int to : tree[nd]) {
			if (to == fa || vis[to] == -1) continue;
			int id_top = 0;
			dfs_fix(to, nd, id_top, to);
			vector< vector<int> > &arr = table[block_id[to]];
			if (arr.empty()) {
				arr.resize(id_top + 1);
				dfs_calc(to, nd, table[block_id[to]]);
			}
		}
		// calc keypoint info
		id[nd] = id_keypt++;
		for (int i = 0; i <= lgn; i++) {
			if ((1 << i) + 1 <= (int)stk.size())
				parent[i].push_back(stk[stk.size() - 1 - (1 << i)]);
			else parent[i].push_back(0);
		}
		stk.pop_back();
		return 0;
	}
}

void jump_preprocess()
{
	lgn = 0, n = 1;
	while (n < N) {
		n <<= 1;
		lgn++;
	}
	int bound = max(lgn >> 2, 1);
	hash_value.resize(N + 1);
    vis.resize(N + 1);
	id.resize(N + 1);
	block_top.resize(N + 1);
	block_id.resize(N + 1);
	block_ptr.resize(N + 1);
	stk.clear();
	table.resize(1 << (bound << 1));
	id_keypt = 0;
	parent.resize(lgn + 1);
	lg.resize(N + 1);
	lg[1] = 0;
	for (int i = 2; i <= N; i++)
		lg[i] = lg[i >> 1] + 1;
	// cut tree
	dfs_cut(root, 0, bound);
}

extern int ladder_query(int u, int k);

int jump_query(int u, int k)
{
	if (vis[u] != -1) {
		vector<int> &arr = table[block_id[u]][id[u]];
		if (k < (int)arr.size()) {
			return block_array[block_ptr[u] + arr[k]];
		}
		int par = block_top[u];
		k -= depth[u] - depth[par];
		u = par;
	}
    if (k == 0) return u;
	int lgk = lg[k];
	u = parent[lgk][id[u]];
	return ladder_query(u, k - (1 << lgk));
}

