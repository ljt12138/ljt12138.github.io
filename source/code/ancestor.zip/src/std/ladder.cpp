#include "../tree/tree.h"
#include "ladder.h"
#include <vector>
#include <algorithm>
#include <cassert>

using std::max;
using std::vector;
using std::reverse;

static vector< int > ladder_depth;
static vector< int > ladder_array;

static void extend_ladder(int nd, int ptr)
{
	vector<int> &arr = ladder_array;
	int cur = father[arr[ptr]], len = arr.size() - ptr;
	for (auto i = arr.begin() + ptr; i != arr.end(); i++) {
		ladder_depth[*i] += len + ptr;
	}
	reverse(arr.begin() + ptr, arr.end());
	for (int i = 0; i < len; i++) {
		arr.push_back(cur);
		cur = father[cur];
	}
	reverse(arr.begin() + ptr, arr.end());
	// doubling ladder length 
}

static void dfs_cut(int nd, int fa, int ptr)
{
	ladder_depth[nd] = ladder_array.size() - ptr;
	// depth in ladder
	ladder_array.push_back(nd);
	// put inside ladder array
	int hev = 0;
	for (int to : tree[nd]) {
		if (to == fa) continue;
		if (!hev || height[hev] < height[to])
			hev = to;
	}
	if (hev == 0) {
		extend_ladder(nd, ptr);
		// extend ladder length 
	} else {
		dfs_cut(hev, nd, ptr);
		for (int to : tree[nd]) {
			if (to == fa || to == hev) continue;
			dfs_cut(to, nd, ladder_array.size());
		}
	}
}

void ladder_preprocess()
{
	ladder_depth.resize(N + 1);
	ladder_array.clear();
	dfs_cut(root, 0, 0);
}

int ladder_query(int u, int k)
{
	int ans = ladder_array[ladder_depth[u]-k];
	return ans;
}

