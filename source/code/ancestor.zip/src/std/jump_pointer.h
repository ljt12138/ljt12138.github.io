#pragma once

void jump_preprocess();
int jump_query(int u, int k);
