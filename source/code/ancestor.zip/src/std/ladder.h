#pragma once

void ladder_preprocess();
int ladder_query(int u, int k);

