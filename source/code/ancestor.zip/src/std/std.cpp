#include "std.h"
#include "../tree/tree.h"
#include "ladder.h"
#include "jump_pointer.h"
#include <vector>
#include <cassert>
#include <cstdio>

static std::vector< int > lg;

void std_preprocess()
{
	ladder_preprocess();
	jump_preprocess();
	lg.resize(N + 1);
    lg[1] = 0;
	for (int i = 2; i <= N; i++) 
		lg[i] = lg[i>>1] + 1;
}

int std_query(int u, int k)
{
	return jump_query(u, k);
}
