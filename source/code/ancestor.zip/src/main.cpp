#include "tree/tree.h"
#include "std/std.h"
#include "brute/brute_jump.h"
#include <cstdlib>
#include <ctime>
#include <cstdio>
#include <cassert>

void random_tree(int N)
{
	srand(19260817);
	init_tree(N, 1);
	for (int i = 2; i <= N; i++) {
		int p = rand() % (i-1) + 1;
		push_tree(p, i);
	}
	preprocess_tree();
}

void test_brute_jump(int N)
{
	srand(998244353);
	printf("now test brute\n");
	clock_t s = clock();
	brute_preprocess();
	int Q = 5 * N, ans = 0;
	for (int i = 1; i <= Q; i++) {
		int u = rand() % N + 1, k = rand() % depth[u];
		ans ^= brute_query(u, k);
	}
	clock_t e = clock();
	printf("check: %d\ntime: %.3lf\n", ans, 1.0*(e-s)/CLOCKS_PER_SEC);
}

void test_std(int N)
{
	srand(998244353);
	printf("now test std\n");
	clock_t s = clock();
	std_preprocess();
	int Q = 5 * N, ans = 0;
	for (int i = 1; i <= Q; i++) {
		int u = rand() % N + 1, k = rand() % depth[u];
		ans ^= std_query(u, k);
	}
	clock_t e = clock();
	printf("check: %d\ntime: %.3lf\n", ans, 1.0*(e-s)/CLOCKS_PER_SEC);
}

int main(int argc, char **argv)
{
	if (argc != 2) {
		printf("usage: \"./main x\", x is size of tree\n"); 
		return 0;
	}
	int N = atoi(argv[1]);
	random_tree(N);
	test_brute_jump(N);
	test_std(N);
	return 0;
}

